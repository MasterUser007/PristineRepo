# FactorEngine
See the full documentation in the FactorEngine/ folder.