## Benchmarking Details

Each benchmark measures time-to-factor across various bit-length composites. Results are logged to CSV and visualized for comparison with GMP-ECM and YAFU.