## Usage

Run the engine:
```bash
python3 engine_core.py
```

Run benchmarks:
```bash
python3 benchmark_tests.py
```

Visualize benchmark results:
```bash
python3 visualize_benchmarks.py
```