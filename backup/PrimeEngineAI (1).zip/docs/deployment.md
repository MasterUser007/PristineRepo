## Deployment (Docker)

```bash
docker build -t factoring-engine .
docker run -it factoring-engine
```