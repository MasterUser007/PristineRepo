from engine_core import main_factoring_engine

if __name__ == "__main__":
    result = main_factoring_engine(input_number=123456789987654321)
    print("Factoring result:", result)
